(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["firstpage-firstpage-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/firstpage/firstpage.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/firstpage/firstpage.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header *ngFor=\"let item of toprinted\">\n  <ion-toolbar>\n    <ion-title>{{item.row_name}}</ion-title>\n    <span style=\"margin-left: 6%;\">{{item.status}}</span>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div  *ngFor=\"let item of toprinted\" style=\"background-color: dimgrey;\">\n  <img class=\"title-image\" src=\"/assets/{{item.img}}\" width=\"200\" height=\"100\" style=\"margin-left: 9%;\" id=\"1\" (click)=\"onClick($event)\"/>\n<ion-list>\n  <ion-item>\n    <ion-label>{{item.position}}</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{item.real_name}}</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{item.fans}}</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{item.connection}}</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{item.type}}</ion-label>\n  </ion-item>\n</ion-list>\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/firstpage/firstpage-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/firstpage/firstpage-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: FirstpagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FirstpagePageRoutingModule", function() { return FirstpagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _firstpage_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./firstpage.page */ "./src/app/firstpage/firstpage.page.ts");




var routes = [
    {
        path: '',
        component: _firstpage_page__WEBPACK_IMPORTED_MODULE_3__["FirstpagePage"]
    }
];
var FirstpagePageRoutingModule = /** @class */ (function () {
    function FirstpagePageRoutingModule() {
    }
    FirstpagePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], FirstpagePageRoutingModule);
    return FirstpagePageRoutingModule;
}());



/***/ }),

/***/ "./src/app/firstpage/firstpage.module.ts":
/*!***********************************************!*\
  !*** ./src/app/firstpage/firstpage.module.ts ***!
  \***********************************************/
/*! exports provided: FirstpagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FirstpagePageModule", function() { return FirstpagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _firstpage_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./firstpage-routing.module */ "./src/app/firstpage/firstpage-routing.module.ts");
/* harmony import */ var _firstpage_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./firstpage.page */ "./src/app/firstpage/firstpage.page.ts");







var FirstpagePageModule = /** @class */ (function () {
    function FirstpagePageModule() {
    }
    FirstpagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _firstpage_routing_module__WEBPACK_IMPORTED_MODULE_5__["FirstpagePageRoutingModule"]
            ],
            declarations: [_firstpage_page__WEBPACK_IMPORTED_MODULE_6__["FirstpagePage"]]
        })
    ], FirstpagePageModule);
    return FirstpagePageModule;
}());



/***/ }),

/***/ "./src/app/firstpage/firstpage.page.scss":
/*!***********************************************!*\
  !*** ./src/app/firstpage/firstpage.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2ZpcnN0cGFnZS9maXJzdHBhZ2UucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/firstpage/firstpage.page.ts":
/*!*********************************************!*\
  !*** ./src/app/firstpage/firstpage.page.ts ***!
  \*********************************************/
/*! exports provided: FirstpagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FirstpagePage", function() { return FirstpagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _jsonfile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../jsonfile.service */ "./src/app/jsonfile.service.ts");



var FirstpagePage = /** @class */ (function () {
    function FirstpagePage(jsonService) {
        var _this = this;
        this.jsonService = jsonService;
        this.toprinted = [];
        this.positionNo = localStorage.getItem("mykey");
        this.jsonService.getJSON().subscribe(function (data) {
            _this.value = data;
            console.log(data);
            _this.value.forEach(function (x) {
                if (x.hasOwnProperty("row_data")) {
                    _this.qwerty = x.row_data;
                    _this.qwerty.forEach(function (ele) {
                        if (ele.position == _this.positionNo) {
                            _this.toprinted.push(ele);
                        }
                    });
                }
            });
        });
    }
    FirstpagePage.prototype.ngOnInit = function () {
    };
    FirstpagePage.ctorParameters = function () { return [
        { type: _jsonfile_service__WEBPACK_IMPORTED_MODULE_2__["JsonfileService"] }
    ]; };
    FirstpagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-firstpage',
            template: __webpack_require__(/*! raw-loader!./firstpage.page.html */ "./node_modules/raw-loader/index.js!./src/app/firstpage/firstpage.page.html"),
            styles: [__webpack_require__(/*! ./firstpage.page.scss */ "./src/app/firstpage/firstpage.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_jsonfile_service__WEBPACK_IMPORTED_MODULE_2__["JsonfileService"]])
    ], FirstpagePage);
    return FirstpagePage;
}());



/***/ }),

/***/ "./src/app/jsonfile.service.ts":
/*!*************************************!*\
  !*** ./src/app/jsonfile.service.ts ***!
  \*************************************/
/*! exports provided: JsonfileService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonfileService", function() { return JsonfileService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var JsonfileService = /** @class */ (function () {
    function JsonfileService(http) {
        this.http = http;
        this.getJSON().subscribe(function (data) {
            // console.log(data);
        });
    }
    JsonfileService.prototype.getJSON = function () {
        return this.http.get("./assets/avn.json");
    };
    JsonfileService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    JsonfileService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], JsonfileService);
    return JsonfileService;
}());



/***/ })

}]);
//# sourceMappingURL=firstpage-firstpage-module-es5.js.map